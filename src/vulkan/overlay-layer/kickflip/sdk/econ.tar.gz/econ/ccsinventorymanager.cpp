#include "ccsinventorymanager.hpp"
#include "../../mem/memory.hpp"
#include "../../frame.hpp"
#include "../../mem/virtual.hpp"

CCSInventoryManager* CCSInventoryManager::GetInstance() {
    if (!kf->getFunction(GetInvManager)) return nullptr;
    typedef CCSInventoryManager* (*GetInventoryManagerFn2)();
    GetInventoryManagerFn2 func = (GetInventoryManagerFn2)(kf->getFunction(GetInvManager));
    return func();
}
