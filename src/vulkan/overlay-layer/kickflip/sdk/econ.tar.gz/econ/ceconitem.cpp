#include "ceconitem.hpp"
#include "ceconitemschema.hpp"
#include "../../mem/memory.hpp"
#include "../../frame.hpp"
#include "../../mem/virtual.hpp"
#include "../interface/Source2Client.hpp"

void CEconItem::SetDynamicAttributeValue(int index, void* value) {
    CEconItemSchema* pItemSchema =  CSource2Client::Get()->GetEconItemSystem()->GetEconItemSchema();
        
    if (!pItemSchema) return;

    void* pAttributeDefinitionInterface =
        pItemSchema->GetAttributeDefinitionInterface(index);
    if (!pAttributeDefinitionInterface) return;

    if (!kf->getFunction(SetDynamicAttributeValueUint)) return;
    typedef void __attribute__((fastcall))  (*SetDynamicAttributeItemUintFn2)(CEconItem*, void*, void*);
     SetDynamicAttributeItemUintFn2 func = (SetDynamicAttributeItemUintFn2)(kf->getFunction(SetDynamicAttributeValueUint));
    func(this, pAttributeDefinitionInterface, value);
}

void CEconItem::SetDynamicAttributeValueString(int index, const char* value) {
    // CS2FIXME: Function got inlined and cannot be sigscanned.
}

CEconItem* CEconItem::CreateInstance() {
     if (!kf->getFunction(CreateSharedObject)) return nullptr;
    typedef CEconItem*  (*CreateSharedObjectSubclassEconItemFn2)();
     CreateSharedObjectSubclassEconItemFn2 func = (CreateSharedObjectSubclassEconItemFn2)(kf->getFunction(CreateSharedObject));

 
    return func();
}
