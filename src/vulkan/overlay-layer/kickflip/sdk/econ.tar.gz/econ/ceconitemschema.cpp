#include "ceconitemschema.hpp"

#include "../../mem/memory.hpp"
#include "../../frame.hpp"
#include "../../mem/virtual.hpp"

bool CPaintKit::UsesLegacyModel() {
    if (!this || !memory::fnIsPaintKitUsingLegacyModel) return false;
    return memory::fnIsPaintKitUsingLegacyModel(this->sName);
}
