#include "cgcclient.hpp"

#include "../../mem/memory.hpp"

#include "../../mem/virtual.hpp"

CGCClientSharedObjectCache* CGCClient::FindSOCache(SOID_t ID,
                                                   bool bCreateIfMissing) {
    if (!memory::fnFindSOCache) return nullptr;
    return memory::fnFindSOCache(this, ID, bCreateIfMissing);
}
