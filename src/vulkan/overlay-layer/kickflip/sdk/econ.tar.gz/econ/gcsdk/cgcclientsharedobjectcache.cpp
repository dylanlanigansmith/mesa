#include "cgcclientsharedobjectcache.hpp"

#include "../../mem/memory.hpp"

#include "../../mem/virtual.hpp"

CGCClientSharedObjectTypeCache* CGCClientSharedObjectCache::CreateBaseTypeCache(
    int nClassID) {
    if (!memory::fnCreateBaseTypeCache) return nullptr;
    return memory::fnCreateBaseTypeCache(this, nClassID);
}
