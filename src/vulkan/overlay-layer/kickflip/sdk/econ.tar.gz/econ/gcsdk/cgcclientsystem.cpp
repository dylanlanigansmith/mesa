#include "cgcclientsystem.hpp"

#include "../../mem/memory.hpp"

#include "../../mem/virtual.hpp"

CGCClientSystem* CGCClientSystem::GetInstance() {
    if (!memory::fnGetClientSystem) return nullptr;
    return memory::fnGetClientSystem();
}
